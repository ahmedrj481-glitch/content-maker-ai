'use strict';

(() => {
  const $ = (id) => document.getElementById(id);
  const topic = $('topic');
  const kind = $('kind');
  const result = $('result');
  const saved = $('saved');
  const make = $('make');
  const copy = $('copy');
  const save = $('save');
  let activeTool = 'ideas';
  let currentDraft = '';

  const toolNames = {
    ideas: 'أفكار محتوى', script: 'كتابة سيناريو',
    caption: 'وصف ومنشور', storyboard: 'خطة فيديو'
  };

  function buildDraft(text, platform, tool) {
    const intro = `الموضوع: ${text}\nالمنصة: ${platform}\n\n`;
    switch (tool) {
      case 'script':
        return intro + `العنوان: ${text}\n\nالمشهد 1 – جذب الانتباه (0–5 ثوانٍ):\nابدأ بسؤال أو معلومة مثيرة عن الموضوع.\n\nالمشهد 2 – الفكرة الرئيسية:\nاشرح الفكرة ببساطة، مع مثال واضح.\n\nالمشهد 3 – الخلاصة:\nلخّص أهم نقطة وقدم نصيحة عملية.\n\nالخاتمة:\nاطلب من المشاهد كتابة رأيه أو متابعة الحساب.\n\nملاحظة: هذه مسودة أولية قابلة للتعديل وليست مولدة بنموذج ذكاء اصطناعي.`;
      case 'caption':
        return intro + `${text}\n\nما رأيكم؟ شاركونا آراءكم وتجاربكم في التعليقات.\n\n#صناعة_المحتوى #محتوى_عربي #${text.replace(/\s+/g, '_').slice(0, 30)}\n\nملاحظة: عدّل النص والوسوم بما يناسب منشورك.`;
      case 'storyboard':
        return intro + `خطة الفيديو المقترحة:\n\n1. الافتتاحية: لقطة قريبة مع عنوان جذاب.\n2. تقديم الموضوع: لقطة توضح الفكرة الأساسية.\n3. التفاصيل: 2 إلى 3 لقطات داعمة أو أمثلة.\n4. النتيجة: عرض الخلاصة أو الحل.\n5. النهاية: دعوة للتفاعل والمتابعة.\n\nأضف تعليقاً صوتياً وموسيقى مرخصة وانتقالات مناسبة.\n\nملاحظة: هذه خطة تصوير نصية وليست ملف فيديو جاهزاً.`;
      default:
        return intro + `أفكار يمكنك تطويرها:\n\n1. شرح الموضوع للمبتدئين بطريقة مبسطة.\n2. أكثر 5 أخطاء شائعة مرتبطة بالموضوع.\n3. حقيقة أو معلومة قد لا يعرفها الجمهور.\n4. خطوات عملية للاستفادة من الموضوع.\n5. مقارنة بين طريقتين أو فكرتين.\n\nاختر فكرة واحدة، وحدد جمهورك، ثم ابدأ بمقدمة تشد الانتباه.\n\nملاحظة: هذه اقتراحات قالبية أولية وليست توليداً فعلياً بالذكاء الاصطناعي.`;
    }
  }

  document.querySelectorAll('[data-tool]').forEach((button) => {
    button.addEventListener('click', () => {
      activeTool = button.dataset.tool;
      document.querySelectorAll('[data-tool]').forEach((item) => item.setAttribute('aria-pressed', String(item === button)));
      result.textContent = `تم اختيار: ${toolNames[activeTool]}. اكتب موضوعك ثم اضغط «جهّز المسودة».`;
      topic.focus();
    });
  });

  make.addEventListener('click', () => {
    const text = topic.value.trim();
    if (!text) {
      result.textContent = 'اكتب موضوع المحتوى أو فكرتك أولاً، ثم اضغط «جهّز المسودة».';
      topic.focus();
      return;
    }
    currentDraft = buildDraft(text, kind.value, activeTool);
    result.textContent = currentDraft;
  });

  copy.addEventListener('click', async () => {
    const text = currentDraft || result.textContent;
    if (!text || text === 'ستظهر المسودة هنا.') {
      result.textContent = 'جهّز مسودة أولاً حتى تتمكن من نسخها.';
      return;
    }
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        const temp = document.createElement('textarea');
        temp.value = text;
        temp.style.position = 'fixed'; temp.style.opacity = '0';
        document.body.appendChild(temp); temp.select();
        const ok = document.execCommand('copy'); temp.remove();
        if (!ok) throw new Error('copy failed');
      }
      result.textContent = text + '\n\n✓ تم نسخ النص.';
    } catch (_) {
      result.textContent = text + '\n\nتعذر النسخ التلقائي. اضغط مطولاً على النص وحدده ثم اختر نسخ.';
    }
  });

  function readDrafts() {
    try { return JSON.parse(localStorage.getItem('contentMakerDrafts') || '[]'); }
    catch (_) { return []; }
  }

  function renderSaved() {
    const drafts = readDrafts();
    saved.replaceChildren();
    if (!drafts.length) {
      saved.textContent = 'لا توجد مسودات بعد.';
      return;
    }
    drafts.forEach((draft, index) => {
      const item = document.createElement('div');
      item.className = 'saved-item';
      const heading = document.createElement('strong');
      heading.textContent = `${draft.title} · ${draft.date}`;
      const body = document.createElement('p');
      body.textContent = draft.text;
      const load = document.createElement('button');
      load.type = 'button'; load.textContent = 'فتح المسودة';
      load.addEventListener('click', () => { currentDraft = draft.text; result.textContent = draft.text; window.scrollTo({ top: result.getBoundingClientRect().top + window.scrollY - 100, behavior: 'smooth' }); });
      const remove = document.createElement('button');
      remove.type = 'button'; remove.textContent = 'حذف';
      remove.addEventListener('click', () => {
        const next = readDrafts(); next.splice(index, 1);
        localStorage.setItem('contentMakerDrafts', JSON.stringify(next)); renderSaved();
      });
      item.append(heading, body, load, document.createTextNode(' '), remove);
      saved.appendChild(item);
    });
  }

  save.addEventListener('click', () => {
    if (!currentDraft) {
      result.textContent = 'جهّز مسودة أولاً قبل حفظها.';
      return;
    }
    try {
      const drafts = readDrafts();
      drafts.unshift({ title: topic.value.trim().slice(0, 60) || toolNames[activeTool], date: new Date().toLocaleString('ar'), text: currentDraft });
      localStorage.setItem('contentMakerDrafts', JSON.stringify(drafts));
      renderSaved();
      result.textContent = currentDraft + '\n\n✓ تم حفظ المسودة على هذا الجهاز.';
    } catch (_) {
      result.textContent = currentDraft + '\n\nتعذر الحفظ. تحقق من مساحة التخزين في المتصفح.';
    }
  });

  renderSaved();
})();
